package cn.itcast.tags.test

object EtlAppTest {
	
	def main(args: Array[String]): Unit = {
		println("Hello World...........")
	}
	
}
