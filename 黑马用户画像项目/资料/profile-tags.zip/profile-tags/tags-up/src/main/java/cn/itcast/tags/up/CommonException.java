package cn.itcast.tags.up;

public class CommonException extends RuntimeException {
}
