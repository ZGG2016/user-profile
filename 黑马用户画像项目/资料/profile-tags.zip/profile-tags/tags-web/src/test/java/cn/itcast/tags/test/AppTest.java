package cn.itcast.tags.test;

public class AppTest {
	public static void main(String[] args) {
		System.out.println("hello world...................");
	}

}
