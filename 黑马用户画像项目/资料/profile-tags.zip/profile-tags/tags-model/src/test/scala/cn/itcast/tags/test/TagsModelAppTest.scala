package cn.itcast.tags.test

object TagsModelAppTest {
	
	def main(args: Array[String]): Unit = {
		println("Hello World................")
	}
	
}
